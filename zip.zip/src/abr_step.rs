//! ABR Measurement Update — Relational Treatment Path
//!
//! Treatment boundary: This file applies Kernel V8 operators exclusively to the
//! declared topology from declaration.rs. No statistical estimation or matrix
//! inversion is used. Operators are applied in declared sequence: A → B → R.
//!
//! ─── Kernel V8 Operators (§11) ────────────────────────────────────────────────
//!
//!   A(x)[e] = x[s] − x[t]
//!     Adjacency operator: difference between source and target locus values.
//!     Applied to measurement residual: how much does the observed feature
//!     differ from the predicted landmark position?
//!
//!   B(g)[e] = g[e] + Σ_{f ∈ succ(e)} g[f]
//!     Forward accumulation: each edge accumulates the values of its successors.
//!     Propagates the residual forward through the topology.
//!
//!   R(g)[e] = g[e] + ρ[src(e)] · (Σ_{succ(e)} g − Σ_{pred(e)} g)
//!     Relational operator: weighted balance of successor vs. predecessor flows.
//!     ρ[i] = ρ_base · χ[i] / (χ₀ + χ[i])   (saturating weight from declaration)
//!
//! ─── Complexity ───────────────────────────────────────────────────────────────
//!
//!   All operators iterate over edges only: O(|E|) = O(n·k)
//!   where n = number of loci, k = average degree.
//!   For this topology: |E| = 2, k = 1 → O(2) edge passes per operator.
//!   No matrix inversion. No backpropagation. No statistical estimation.
//!
//! ─── Declared Topology (from declaration.rs) ──────────────────────────────────
//!
//!   e₀: camera_feature (0) → landmark (1)      EdgeProvenance::Coupling
//!   e₁: landmark (1)       → display_update (2) EdgeProvenance::Coupling
//!   Interior locus: landmark (1) — A→B→R admissibility satisfied.

use crate::declaration::{MDeclaration, RelationalEdge};

// ── ABR inputs ─────────────────────────────────────────────────────────────────

/// Observable measurement data supplied from outside the declared topology.
/// These come from instrument readings, not from priors or models.
pub struct AbrInputs {
    /// Measurement residual at camera_feature locus (pixels).
    /// Independently observed: detected pixel − predicted pixel, per axis.
    /// Using u-axis (horizontal) for this scalar demonstration.
    pub observed_residual_u: f64,
    pub observed_residual_v: f64,
}

impl AbrInputs {
    /// Inputs that correspond to the EKF example:
    ///   predicted pixel: H·x ≈ (27.4, -10.9), observed: (28.4, -10.9)
    ///   → residual_u = 1.0 px, residual_v = 0.0 px
    pub fn ar_example() -> Self {
        AbrInputs {
            observed_residual_u: 1.0,
            observed_residual_v: 0.0,
        }
    }
}

// ── Edge value map ─────────────────────────────────────────────────────────────

/// Mutable edge values during operator application.
/// Keyed by edge id.
#[derive(Debug, Clone)]
pub struct EdgeValues {
    pub values: Vec<f64>,
}

impl EdgeValues {
    pub fn new(n_edges: usize) -> Self {
        EdgeValues { values: vec![0.0; n_edges] }
    }

    pub fn get(&self, edge_id: usize) -> f64 {
        self.values[edge_id]
    }

    pub fn set(&mut self, edge_id: usize, v: f64) {
        self.values[edge_id] = v;
    }
}

// ── Operator A ─────────────────────────────────────────────────────────────────

/// A(x)[e] = x[s] − x[t]
///
/// Applied to the declared edge e₀ (camera_feature → landmark):
///   value = residual at source (camera_feature) − residual at target (landmark, = 0 initially)
///   This encodes: how far is the observation from the declared landmark position?
///
/// Returns (edge_values_after_A, ops_A)
pub fn apply_a(
    decl: &MDeclaration,
    locus_values: &[f64],   // one scalar value per locus (x[locus_id])
) -> (EdgeValues, usize) {
    let mut g = EdgeValues::new(decl.edges.len());
    let mut ops = 0usize;

    for edge in &decl.edges {
        // A(x)[e] = x[source] − x[target]
        let val = locus_values[edge.source] - locus_values[edge.target];
        g.set(edge.id, val);
        ops += 1;  // one subtraction per edge
    }

    (g, ops)
}

// ── Operator B ─────────────────────────────────────────────────────────────────

/// B(g)[e] = g[e] + Σ_{f ∈ succ(e)} g[f]
///
/// For e₀ (camera_feature → landmark):
///   succ(e₀) = {e₁}  (e₁ departs from landmark = target of e₀)
///   B(g)[e₀] = g[e₀] + g[e₁]
///
/// For e₁ (landmark → display_update):
///   succ(e₁) = {} (display_update has no outgoing edges)
///   B(g)[e₁] = g[e₁]
///
/// Returns (edge_values_after_B, ops_B)
pub fn apply_b(
    decl: &MDeclaration,
    g_in: &EdgeValues,
) -> (EdgeValues, usize) {
    let mut g_out = g_in.clone();
    let mut ops = 0usize;

    for edge in &decl.edges {
        // Successors of edge e: edges whose source == target of e
        let succ_sum: f64 = successors_of_edge(decl, edge)
            .iter()
            .map(|f| g_in.get(f.id))
            .sum();
        let n_succ = successors_of_edge(decl, edge).len();
        g_out.set(edge.id, g_in.get(edge.id) + succ_sum);
        ops += n_succ;  // one addition per successor
    }

    (g_out, ops)
}

// ── Operator R ─────────────────────────────────────────────────────────────────

/// R(g)[e] = g[e] + ρ[src(e)] · (Σ_{succ(e)} g − Σ_{pred(e)} g)
///
/// ρ[i] = ρ_base · χ[i] / (χ₀ + χ[i])   (saturating weight from M declaration)
///
/// For e₀ (camera_feature → landmark), src = camera_feature (id=0):
///   ρ[0] = 0.025 · 8.0 / (2.0 + 8.0) = 0.025 · 0.8 = 0.020
///   succ(e₀) = {e₁}, pred(e₀) = {}
///   R(g)[e₀] = g[e₀] + 0.020 · (g[e₁] − 0)
///
/// For e₁ (landmark → display_update), src = landmark (id=1):
///   ρ[1] = 0.025 · 4.0 / (2.0 + 4.0) = 0.025 · 0.6667 = 0.01667
///   succ(e₁) = {}, pred(e₁) = {e₀}
///   R(g)[e₁] = g[e₁] + 0.01667 · (0 − g[e₀])
///
/// Returns (edge_values_after_R, ops_R, rho_values)
pub fn apply_r(
    decl: &MDeclaration,
    g_in: &EdgeValues,
) -> (EdgeValues, usize, Vec<f64>) {
    let mut g_out = g_in.clone();
    let mut ops = 0usize;
    let mut rho_values = vec![0.0; decl.loci.len()];

    // Pre-compute ρ for each locus (stored for reporting)
    for locus in &decl.loci {
        rho_values[locus.id] = decl.rho(locus.id);
    }

    for edge in &decl.edges {
        let rho_src = rho_values[edge.source];

        let succ_edges = successors_of_edge(decl, edge);
        let pred_edges = predecessors_of_edge(decl, edge);

        let succ_sum: f64 = succ_edges.iter().map(|f| g_in.get(f.id)).sum();
        let pred_sum: f64 = pred_edges.iter().map(|f| g_in.get(f.id)).sum();

        // R(g)[e] = g[e] + ρ[src] · (succ_sum − pred_sum)
        let r_val = g_in.get(edge.id) + rho_src * (succ_sum - pred_sum);
        g_out.set(edge.id, r_val);

        // ops: count additions and the multiply
        ops += succ_edges.len() + pred_edges.len() + 1;
    }

    (g_out, ops, rho_values)
}

// ── Helper functions ───────────────────────────────────────────────────────────

/// Edges that depart from the target of the given edge.
/// (Successors of edge e are edges whose source == target(e))
fn successors_of_edge<'a>(
    decl: &'a MDeclaration,
    edge: &RelationalEdge,
) -> Vec<&'a RelationalEdge> {
    decl.edges.iter()
        .filter(|f| f.source == edge.target)
        .collect()
}

/// Edges that arrive at the source of the given edge.
/// (Predecessors of edge e are edges whose target == source(e))
fn predecessors_of_edge<'a>(
    decl: &'a MDeclaration,
    edge: &RelationalEdge,
) -> Vec<&'a RelationalEdge> {
    decl.edges.iter()
        .filter(|f| f.target == edge.source)
        .collect()
}

// ── ABR result ─────────────────────────────────────────────────────────────────

/// Complete result of one ABR measurement update step.
pub struct AbrResult {
    /// Edge values after A operator.
    pub g_after_a:         EdgeValues,
    /// Edge values after B operator.
    pub g_after_b:         EdgeValues,
    /// Edge values after R operator (final relational state).
    pub g_after_r:         EdgeValues,

    /// Saturating weights ρ for each locus (for reporting and verification).
    pub rho_values:        Vec<f64>,

    /// Correction at display_update locus (edge e₁ final value),
    /// in the same observable units as the input residual (pixels).
    pub display_correction: f64,

    // Operation counts
    pub ops_a:  usize,
    pub ops_b:  usize,
    pub ops_r:  usize,
    pub total_ops: usize,
}

// ── ABR measurement update ─────────────────────────────────────────────────────

/// Execute one ABR measurement update: A → B → R on the declared topology.
///
/// The observable residual is placed at the camera_feature locus (id=0).
/// The landmark locus (id=1) and display_update locus (id=2) start at zero.
/// Operators propagate the residual through the declared topology.
///
/// No matrix inversion. No statistical model. Operators only.
pub fn abr_measurement_update(
    decl: &MDeclaration,
    inputs: &AbrInputs,
) -> AbrResult {
    // Locus values: observable measurement placed at camera_feature.
    // landmark and display_update are not assumed — they start at zero
    // and receive values through the declared operator chain.
    let locus_values = vec![
        inputs.observed_residual_u,  // camera_feature: from observable measurement
        0.0,                          // landmark: not pre-assumed
        0.0,                          // display_update: not pre-assumed
    ];

    // A: edge differences from locus values
    let (g_a, ops_a) = apply_a(decl, &locus_values);

    // B: forward accumulation
    let (g_b, ops_b) = apply_b(decl, &g_a);

    // R: relational weighting
    let (g_r, ops_r, rho_values) = apply_r(decl, &g_b);

    // Display correction is the final value on edge e₁ (landmark → display_update)
    let display_correction = g_r.get(1);

    let total_ops = ops_a + ops_b + ops_r;

    AbrResult {
        g_after_a: g_a,
        g_after_b: g_b,
        g_after_r: g_r,
        rho_values,
        display_correction,
        ops_a,
        ops_b,
        ops_r,
        total_ops,
    }
}
