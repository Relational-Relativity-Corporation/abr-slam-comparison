//! M Regional Instantiation
//!
//! Origin:    Robin Macomber, Metatron Dynamics, Inc.
//! Generator: Claude (Kernel V8, session 2026-10-19)
//! Region:    Single measurement update step, head-mounted AR
//!
//! ─── Observable Extent ────────────────────────────────────────────────────────
//! Device:  Microsoft HoloLens 2
//! Sources: Microsoft HoloLens 2 hardware specification (public)
//!   - Display resolution:  >2,500 radiants (light points per radian)
//!   - Angular resolution:  47 pixels per degree
//!   - Frame rate:          1080p at 30 Hz
//!   - IMU:                 3-axis accelerometer, gyroscope, magnetometer
//!
//! ─── Declared Parameters ──────────────────────────────────────────────────────
//! ρ_base = 0.025
//!   Derivation: 2,500 radiants / 100,000 scale factor = 0.025
//!   Meaning:    baseline saturating influence per declared locus
//!
//! χ₀ = 2.0 pixels
//!   Derivation: minimum detectable displacement at 47 px/degree
//!               1° ≈ 47 px → sub-degree threshold ≈ 2 px
//!   Meaning:    observable extent at which saturation begins
//!
//! ─── Regional Orientation ─────────────────────────────────────────────────────
//!   Direction of declared relation: camera_feature → landmark → display_update
//!   Interior locus (admissibility): landmark
//!     landmark = target(e₀) = source(e₁) for independently declared e₀, e₁
//!     → full-operator A→B→R admissibility satisfied (Kernel V8 §11)
//!
//! ─── Regional Admission Rule ──────────────────────────────────────────────────
//!   Any locus admitted to this region must:
//!     (a) carry a declared observable extent χ in pixels
//!     (b) connect to at least one other locus via an edge with declared EdgeProvenance
//!     (c) be located within the HoloLens 2 visual field (nominal 52° × 29° FOV)
//!
//! ─── Treatment Boundary ───────────────────────────────────────────────────────
//!   EKF comparator: retains conventional matrix mathematics throughout.
//!                   No Kernel V8 operators applied to EKF path.
//!   ABR treatment:  operators A, B, R applied only to declared topology below.
//!                   No legacy statistical estimation on ABR path.

// ── Declared Parameters ────────────────────────────────────────────────────────

/// Saturating weight base.
/// Provenance: HoloLens 2 radiants density (2,500 radiants / 100,000).
pub const RHO_BASE: f64 = 0.025;

/// Observable extent threshold (pixels) at which saturation begins.
/// Provenance: HoloLens 2 angular resolution, 47 px/degree → ~2 px minimum displacement.
pub const CHI_0: f64 = 2.0;

// ── Edge Provenance ────────────────────────────────────────────────────────────

/// Every declared edge must carry exactly one EdgeProvenance.
/// Kernel V8 §11: Continuation | Coupling | Persistence
#[derive(Debug, Clone, PartialEq)]
pub enum EdgeProvenance {
    /// Same locus tracked across successive time steps.
    Continuation,
    /// Causal link between two distinct, independently declared loci.
    Coupling,
    /// Locus retained without active observation across measurement cycles.
    Persistence,
}

// ── Locus ──────────────────────────────────────────────────────────────────────

/// A declared point in the relational topology.
#[derive(Debug, Clone)]
pub struct Locus {
    pub id:    usize,
    pub label: &'static str,
    /// Observable extent at this locus (pixels). Origin-supplied.
    pub chi:   f64,
}

// ── Relational Edge ────────────────────────────────────────────────────────────

/// A declared directed relation between two loci.
#[derive(Debug, Clone)]
pub struct RelationalEdge {
    pub id:         usize,
    pub source:     usize,        // id of source locus
    pub target:     usize,        // id of target locus
    pub provenance: EdgeProvenance,
    /// Edge value (populated from observable measurement; not assumed).
    pub value:      f64,
}

// ── M Declaration ─────────────────────────────────────────────────────────────

/// Complete M Regional Declaration for this comparison.
pub struct MDeclaration {
    pub region_label: &'static str,
    pub loci:         Vec<Locus>,
    pub edges:        Vec<RelationalEdge>,
    pub rho_base:     f64,
    pub chi_0:        f64,
}

impl MDeclaration {
    /// Construct the declared AR measurement update topology.
    ///
    /// Loci:
    ///   0: camera_feature  — detected image feature, χ = 8.0 px (feature detector window)
    ///   1: landmark        — matched 3-D map point, χ = 4.0 px (landmark patch extent)
    ///   2: display_update  — corrected display pixel, χ = 2.0 px (HoloLens 2 min disp.)
    ///
    /// Edges:
    ///   e₀: camera_feature → landmark   (Coupling) — measurement association
    ///   e₁: landmark → display_update   (Coupling) — correction propagation
    ///
    /// Interior locus: landmark (id = 1)
    ///   landmark = target(e₀) and source(e₁), with e₀ and e₁ independently declared.
    ///   Full-operator admissibility condition satisfied.
    pub fn ar_measurement_update() -> Self {
        let loci = vec![
            Locus { id: 0, label: "camera_feature", chi: 8.0 },
            Locus { id: 1, label: "landmark",        chi: 4.0 },
            Locus { id: 2, label: "display_update",  chi: 2.0 },
        ];

        let edges = vec![
            RelationalEdge {
                id:         0,
                source:     0,  // camera_feature
                target:     1,  // landmark
                provenance: EdgeProvenance::Coupling,
                value:      0.0, // populated from observable measurement residual
            },
            RelationalEdge {
                id:         1,
                source:     1,  // landmark
                target:     2,  // display_update
                provenance: EdgeProvenance::Coupling,
                value:      0.0, // populated by B/R propagation
            },
        ];

        MDeclaration {
            region_label: "AR measurement update — HoloLens 2, single-step",
            loci,
            edges,
            rho_base: RHO_BASE,
            chi_0:    CHI_0,
        }
    }

    /// Saturating weight ρ at locus `locus_id`.
    /// ρ[i] = ρ_base · χ[i] / (χ₀ + χ[i])
    pub fn rho(&self, locus_id: usize) -> f64 {
        let chi = self.loci[locus_id].chi;
        self.rho_base * chi / (self.chi_0 + chi)
    }

    /// Return successor edges for a given locus (edges whose source == locus_id).
    pub fn successors(&self, locus_id: usize) -> Vec<&RelationalEdge> {
        self.edges.iter().filter(|e| e.source == locus_id).collect()
    }

    /// Return predecessor edges for a given locus (edges whose target == locus_id).
    pub fn predecessors(&self, locus_id: usize) -> Vec<&RelationalEdge> {
        self.edges.iter().filter(|e| e.target == locus_id).collect()
    }
}
