//! EKF Measurement Update — Comparator Path
//!
//! Treatment boundary: This file contains conventional Extended Kalman Filter
//! mathematics. No Kernel V8 operators are applied here. This code serves as
//! the comparator against which the ABR relational path is measured.
//!
//! ─── EKF Measurement Update Equations ────────────────────────────────────────
//!
//!   Innovation:     y = z − H·x
//!   Innovation cov: S = H·P·Hᵀ + R
//!   Kalman gain:    K = P·Hᵀ·S⁻¹
//!   State update:   x̂ = x + K·y
//!   Cov update:     P̂ = (I − K·H)·P
//!
//! ─── Complexity Analysis ──────────────────────────────────────────────────────
//!
//!   Let n = state dimension, m = measurement dimension.
//!
//!   H·P (m×n · n×n):          O(m·n²)  multiplications
//!   (H·P)·Hᵀ (m×n · n×m):    O(m²·n)  multiplications  → produces m×m matrix S
//!   S⁻¹ (m×m inversion):      O(m³)    — cubic in measurement dimension
//!   P·Hᵀ (n×n · n×m):         O(n²·m)  multiplications
//!   K = P·Hᵀ · S⁻¹ (n×m·m×m):O(n·m²)  multiplications  → produces n×m gain K
//!   K·y (n×m · m):             O(n·m)
//!   K·H (n×m · m×n):           O(n·m·n) = O(n²·m)
//!   (I−KH)·P (n×n · n×n):     O(n³)    multiplications
//!
//!   Dominant cost: O(n³) for covariance update + O(m³) for innovation inversion.
//!   Verifier finding V-02: inversion is cubic in m (measurement dim), not n.
//!   Both dimensions are recorded in EkfResult for transparency.

/// Dimensions used in this comparison.
/// Chosen to represent a realistic AR visual-inertial landmark update.
pub const STATE_DIM: usize = 6;        // [x, y, z, roll, pitch, yaw]
pub const MEASUREMENT_DIM: usize = 2;  // [pixel_u, pixel_v]

// ── Matrix type ────────────────────────────────────────────────────────────────

/// Row-major dense matrix of f64.
#[derive(Debug, Clone)]
pub struct Matrix {
    pub rows: usize,
    pub cols: usize,
    data:     Vec<f64>,
}

impl Matrix {
    pub fn zeros(rows: usize, cols: usize) -> Self {
        Matrix { rows, cols, data: vec![0.0; rows * cols] }
    }

    pub fn identity(n: usize) -> Self {
        let mut m = Matrix::zeros(n, n);
        for i in 0..n { m.set(i, i, 1.0); }
        m
    }

    pub fn get(&self, r: usize, c: usize) -> f64 {
        self.data[r * self.cols + c]
    }

    pub fn set(&mut self, r: usize, c: usize, v: f64) {
        self.data[r * self.cols + c] = v;
    }

    /// Matrix multiply: (self: r×k) · (other: k×c) → r×c
    /// Returns (result, multiply_ops) where multiply_ops counts scalar multiplications.
    pub fn mul(&self, other: &Matrix) -> (Matrix, usize) {
        assert_eq!(self.cols, other.rows, "dimension mismatch in multiply");
        let mut result = Matrix::zeros(self.rows, other.cols);
        let mut ops = 0usize;
        for i in 0..self.rows {
            for j in 0..other.cols {
                let mut sum = 0.0;
                for k in 0..self.cols {
                    sum += self.get(i, k) * other.get(k, j);
                    ops += 1;
                }
                result.set(i, j, sum);
            }
        }
        (result, ops)
    }

    /// Matrix add: element-wise, same dimensions.
    pub fn add(&self, other: &Matrix) -> Matrix {
        assert_eq!(self.rows, other.rows);
        assert_eq!(self.cols, other.cols);
        let mut result = self.clone();
        for i in 0..self.data.len() {
            result.data[i] += other.data[i];
        }
        result
    }

    /// Matrix subtract: element-wise, same dimensions.
    pub fn sub(&self, other: &Matrix) -> Matrix {
        assert_eq!(self.rows, other.rows);
        assert_eq!(self.cols, other.cols);
        let mut result = self.clone();
        for i in 0..self.data.len() {
            result.data[i] -= other.data[i];
        }
        result
    }

    /// Transpose.
    pub fn transpose(&self) -> Matrix {
        let mut result = Matrix::zeros(self.cols, self.rows);
        for i in 0..self.rows {
            for j in 0..self.cols {
                result.set(j, i, self.get(i, j));
            }
        }
        result
    }

    /// Invert a square matrix using Gaussian elimination with partial pivoting.
    /// Returns (inverse, ops) where ops counts row operations (each is O(n) multiplications).
    /// Complexity: O(n³) in the dimension of this matrix.
    pub fn invert(&self) -> (Matrix, usize) {
        assert_eq!(self.rows, self.cols, "invert requires square matrix");
        let n = self.rows;
        let mut a = self.clone();
        let mut inv = Matrix::identity(n);
        let mut ops = 0usize;

        for col in 0..n {
            // Find pivot
            let mut max_row = col;
            let mut max_val = a.get(col, col).abs();
            for row in (col + 1)..n {
                let v = a.get(row, col).abs();
                if v > max_val { max_val = v; max_row = row; }
            }
            // Swap rows in a and inv
            for c in 0..n {
                let tmp_a = a.get(col, c);
                a.set(col, c, a.get(max_row, c));
                a.set(max_row, c, tmp_a);
                let tmp_i = inv.get(col, c);
                inv.set(col, c, inv.get(max_row, c));
                inv.set(max_row, c, tmp_i);
            }
            // Scale pivot row
            let pivot = a.get(col, col);
            for c in 0..n {
                a.set(col, c, a.get(col, c) / pivot);
                inv.set(col, c, inv.get(col, c) / pivot);
                ops += 1;
            }
            // Eliminate column
            for row in 0..n {
                if row == col { continue; }
                let factor = a.get(row, col);
                for c in 0..n {
                    let new_a = a.get(row, c) - factor * a.get(col, c);
                    a.set(row, c, new_a);
                    let new_i = inv.get(row, c) - factor * inv.get(col, c);
                    inv.set(row, c, new_i);
                    ops += 1;
                }
            }
        }
        (inv, ops)
    }

    /// Scalar multiply.
    pub fn scale(&self, s: f64) -> Matrix {
        let mut result = self.clone();
        for v in result.data.iter_mut() { *v *= s; }
        result
    }

    /// Return the data slice (for display / verification).
    pub fn data(&self) -> &[f64] { &self.data }

    /// Pretty-print for a vector (single column or single row).
    pub fn as_vec_string(&self) -> String {
        if self.cols == 1 {
            let vals: Vec<String> = (0..self.rows)
                .map(|i| format!("{:+.6}", self.get(i, 0)))
                .collect();
            format!("[{}]", vals.join(", "))
        } else if self.rows == 1 {
            let vals: Vec<String> = (0..self.cols)
                .map(|j| format!("{:+.6}", self.get(0, j)))
                .collect();
            format!("[{}]", vals.join(", "))
        } else {
            format!("({}×{} matrix)", self.rows, self.cols)
        }
    }
}

// ── EKF inputs ────────────────────────────────────────────────────────────────

/// Inputs to a single EKF measurement update.
pub struct EkfInputs {
    /// Prior state estimate (n × 1).
    pub x: Matrix,
    /// Prior covariance (n × n).
    pub p: Matrix,
    /// Measurement Jacobian (m × n).
    pub h: Matrix,
    /// Measurement noise covariance (m × m).
    pub r_noise: Matrix,
    /// Measurement vector (m × 1).
    pub z: Matrix,
}

impl EkfInputs {
    /// Construct a representative AR landmark measurement update.
    /// Values are chosen to be numerically realistic for a visual-inertial system.
    pub fn ar_example() -> Self {
        let n = STATE_DIM;
        let m = MEASUREMENT_DIM;

        // Prior state: camera at small offset from origin with slight roll
        let mut x = Matrix::zeros(n, 1);
        x.set(0, 0,  0.05);  // x = 5 cm
        x.set(1, 0, -0.02);  // y = -2 cm
        x.set(2, 0,  1.50);  // z = 1.5 m depth
        x.set(3, 0,  0.01);  // roll  = ~0.57°
        x.set(4, 0, -0.01);  // pitch = ~-0.57°
        x.set(5, 0,  0.00);  // yaw   = 0

        // Prior covariance: moderate uncertainty
        let mut p = Matrix::identity(n);
        for i in 0..n { p.set(i, i, if i < 3 { 0.01 } else { 0.001 }); }

        // Measurement Jacobian: projects 3-D position into pixel (u, v)
        // Simplified: u ≈ f*X/Z, v ≈ f*Y/Z  (focal length f = 47 px/degree × π/180 ≈ 822 px)
        let f = 822.0_f64;
        let z_depth = x.get(2, 0);
        let mut h = Matrix::zeros(m, n);
        h.set(0, 0, f / z_depth);   // ∂u/∂x
        h.set(0, 2, -f * x.get(0, 0) / (z_depth * z_depth)); // ∂u/∂z
        h.set(1, 1, f / z_depth);   // ∂v/∂y
        h.set(1, 2, -f * x.get(1, 0) / (z_depth * z_depth)); // ∂v/∂z

        // Measurement noise: 2 pixel std dev → 4 px² variance on diagonal
        let mut r_noise = Matrix::zeros(m, m);
        r_noise.set(0, 0, 4.0);
        r_noise.set(1, 1, 4.0);

        // Measurement: detected feature at (u=28.4, v=-10.9) pixels
        let mut z = Matrix::zeros(m, 1);
        z.set(0, 0, 28.4);
        z.set(1, 0, -10.9);

        EkfInputs { x, p, h, r_noise, z }
    }
}

// ── EKF result ────────────────────────────────────────────────────────────────

/// All outputs from the EKF measurement update step, with operation accounting.
pub struct EkfResult {
    // Outputs
    pub x_posterior:       Matrix,   // updated state (n × 1)
    pub p_posterior:       Matrix,   // updated covariance (n × n)
    pub innovation:        Matrix,   // y = z − H·x  (m × 1)
    pub kalman_gain:       Matrix,   // K  (n × m)

    // Dimensions (recorded per Verifier finding V-02)
    pub state_dim:         usize,
    pub measurement_dim:   usize,

    // Operation counts (scalar multiplications)
    pub ops_hp:            usize,    // H·P
    pub ops_hpht:          usize,    // (H·P)·Hᵀ
    pub ops_inversion:     usize,    // S⁻¹  — cubic in m
    pub ops_pht:           usize,    // P·Hᵀ
    pub ops_gain:          usize,    // K = P·Hᵀ · S⁻¹
    pub ops_state_update:  usize,    // K·y
    pub ops_kh:            usize,    // K·H
    pub ops_cov_update:    usize,    // (I − K·H)·P
    pub total_ops:         usize,
}

// ── EKF measurement update ────────────────────────────────────────────────────

/// Execute a single EKF measurement update step, counting all scalar operations.
pub fn ekf_measurement_update(inputs: &EkfInputs) -> EkfResult {
    let n = inputs.x.rows;
    let m = inputs.z.rows;

    let h  = &inputs.h;
    let p  = &inputs.p;
    let r  = &inputs.r_noise;
    let x  = &inputs.x;
    let z  = &inputs.z;
    let ht = h.transpose();

    // Innovation: y = z − H·x
    let (hx, _)       = h.mul(x);
    let innovation    = z.sub(&hx);

    // Innovation covariance: S = H·P·Hᵀ + R
    let (hp, ops_hp)    = h.mul(p);
    let (hpht, ops_hpht)= hp.mul(&ht);
    let s               = hpht.add(r);

    // Kalman gain: K = P·Hᵀ · S⁻¹
    let (s_inv, ops_inv) = s.invert();
    let (pht, ops_pht)   = p.mul(&ht);
    let (k, ops_gain)    = pht.mul(&s_inv);

    // State update: x̂ = x + K·y
    let (ky, ops_state)  = k.mul(&innovation);
    let x_posterior      = x.add(&ky);

    // Covariance update: P̂ = (I − K·H)·P
    let i_n              = Matrix::identity(n);
    let (kh, ops_kh)     = k.mul(h);
    let i_minus_kh       = i_n.sub(&kh);
    let (p_posterior, ops_cov) = i_minus_kh.mul(p);

    let total_ops = ops_hp + ops_hpht + ops_inv + ops_pht + ops_gain
                  + ops_state + ops_kh + ops_cov;

    EkfResult {
        x_posterior,
        p_posterior,
        innovation,
        kalman_gain: k,
        state_dim:         n,
        measurement_dim:   m,
        ops_hp,
        ops_hpht,
        ops_inversion:     ops_inv,
        ops_pht,
        ops_gain,
        ops_state_update:  ops_state,
        ops_kh,
        ops_cov_update:    ops_cov,
        total_ops,
    }
}
